interface Expression {
	public int solve();
}
